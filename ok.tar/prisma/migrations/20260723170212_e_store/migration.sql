-- AlterTable
ALTER TABLE "Advertisement" ADD COLUMN     "descriptionAr" TEXT,
ADD COLUMN     "titleAr" TEXT;

-- AlterTable
ALTER TABLE "Category" ADD COLUMN     "descriptionAr" TEXT,
ADD COLUMN     "nameAr" TEXT;

-- AlterTable
ALTER TABLE "Customer" ADD COLUMN     "addressAr" TEXT;

-- AlterTable
ALTER TABLE "Discount" ADD COLUMN     "nameAr" TEXT;

-- AlterTable
ALTER TABLE "Employee" ADD COLUMN     "jobTitleAr" TEXT;

-- AlterTable
ALTER TABLE "Expense" ADD COLUMN     "categoryAr" TEXT,
ADD COLUMN     "descriptionAr" TEXT;

-- AlterTable
ALTER TABLE "LoyaltyDiscountOffer" ADD COLUMN     "descriptionAr" TEXT,
ADD COLUMN     "nameAr" TEXT;

-- AlterTable
ALTER TABLE "Notification" ADD COLUMN     "bodyAr" TEXT,
ADD COLUMN     "titleAr" TEXT;

-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "deliveryAddressAr" TEXT;

-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "descriptionAr" TEXT,
ADD COLUMN     "nameAr" TEXT;

-- AlterTable
ALTER TABLE "ProductImportJob" ADD COLUMN     "fileNameAr" TEXT;

-- AlterTable
ALTER TABLE "Supplier" ADD COLUMN     "addressAr" TEXT,
ADD COLUMN     "fullNameAr" TEXT;

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "fullNameAr" TEXT;
