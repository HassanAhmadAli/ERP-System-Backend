/*
  Warnings:

  - You are about to drop the column `loyaltyPointsUsed` on the `Order` table. All the data in the column will be lost.
  - You are about to drop the column `amountPaid` on the `SalesInvoice` table. All the data in the column will be lost.
  - You are about to drop the `LoyaltyReward` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[storedFileId]` on the table `Category` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterEnum
ALTER TYPE "DiscountScope" ADD VALUE 'CUSTOMER';

-- AlterTable
ALTER TABLE "AuditLog" ALTER COLUMN "entityId" SET DATA TYPE TEXT;

-- AlterTable
ALTER TABLE "Category" ADD COLUMN     "imageUrl" TEXT,
ADD COLUMN     "storedFileId" TEXT;

-- AlterTable
ALTER TABLE "Discount" ADD COLUMN     "customerId" INTEGER;

-- AlterTable
ALTER TABLE "Order" DROP COLUMN "loyaltyPointsUsed";

-- AlterTable
ALTER TABLE "SalesInvoice" DROP COLUMN "amountPaid";

-- DropTable
DROP TABLE "LoyaltyReward";

-- CreateTable
CREATE TABLE "LoyaltyDiscountOffer" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "pointsCost" INTEGER NOT NULL,
    "discountType" "DiscountType" NOT NULL,
    "discountValue" DECIMAL(12,2) NOT NULL,
    "maxUses" INTEGER NOT NULL DEFAULT 1,
    "validityDays" INTEGER NOT NULL DEFAULT 7,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "LoyaltyDiscountOffer_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LoyaltyRedemption" (
    "id" TEXT NOT NULL,
    "customerId" INTEGER NOT NULL,
    "offerId" TEXT NOT NULL,
    "discountId" INTEGER NOT NULL,
    "pointsSpent" INTEGER NOT NULL,
    "redeemedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "LoyaltyRedemption_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Category_storedFileId_key" ON "Category"("storedFileId");

-- AddForeignKey
ALTER TABLE "Category" ADD CONSTRAINT "Category_storedFileId_fkey" FOREIGN KEY ("storedFileId") REFERENCES "StoredFile"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Discount" ADD CONSTRAINT "Discount_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LoyaltyRedemption" ADD CONSTRAINT "LoyaltyRedemption_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LoyaltyRedemption" ADD CONSTRAINT "LoyaltyRedemption_offerId_fkey" FOREIGN KEY ("offerId") REFERENCES "LoyaltyDiscountOffer"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LoyaltyRedemption" ADD CONSTRAINT "LoyaltyRedemption_discountId_fkey" FOREIGN KEY ("discountId") REFERENCES "Discount"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
