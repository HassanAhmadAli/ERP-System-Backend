/*
  Warnings:

  - The values [CUSTOMER] on the enum `DiscountScope` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "DiscountScope_new" AS ENUM ('GLOBAL', 'CATEGORY', 'PRODUCT');
ALTER TABLE "Discount" ALTER COLUMN "scope" TYPE "DiscountScope_new" USING ("scope"::text::"DiscountScope_new");
ALTER TYPE "DiscountScope" RENAME TO "DiscountScope_old";
ALTER TYPE "DiscountScope_new" RENAME TO "DiscountScope";
DROP TYPE "public"."DiscountScope_old";
COMMIT;
