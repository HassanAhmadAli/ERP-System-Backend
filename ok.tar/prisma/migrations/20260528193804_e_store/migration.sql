-- CreateEnum
CREATE TYPE "StockoutAlertStatus" AS ENUM ('PENDING', 'ACKNOWLEDGED', 'RESOLVED', 'DISMISSED');

-- CreateTable
CREATE TABLE "StockoutPrediction" (
    "id" SERIAL NOT NULL,
    "productId" INTEGER NOT NULL,
    "currentStock" INTEGER NOT NULL,
    "dailyAverageSales" DECIMAL(10,2) NOT NULL,
    "predictedStockoutDate" TIMESTAMP(3) NOT NULL,
    "daysUntilStockout" INTEGER NOT NULL,
    "confidence" DECIMAL(3,2) NOT NULL DEFAULT 0.8,
    "calculatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "StockoutPrediction_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "StockoutAlert" (
    "id" SERIAL NOT NULL,
    "productId" INTEGER NOT NULL,
    "status" "StockoutAlertStatus" NOT NULL DEFAULT 'PENDING',
    "severity" TEXT NOT NULL DEFAULT 'medium',
    "message" TEXT NOT NULL,
    "predictedDate" TIMESTAMP(3) NOT NULL,
    "acknowledgedAt" TIMESTAMP(3),
    "resolvedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "StockoutAlert_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "StockoutPrediction_productId_idx" ON "StockoutPrediction"("productId");

-- CreateIndex
CREATE INDEX "StockoutPrediction_predictedStockoutDate_idx" ON "StockoutPrediction"("predictedStockoutDate");

-- CreateIndex
CREATE UNIQUE INDEX "StockoutPrediction_productId_calculatedAt_key" ON "StockoutPrediction"("productId", "calculatedAt");

-- CreateIndex
CREATE INDEX "StockoutAlert_productId_idx" ON "StockoutAlert"("productId");

-- CreateIndex
CREATE INDEX "StockoutAlert_status_idx" ON "StockoutAlert"("status");

-- CreateIndex
CREATE INDEX "StockoutAlert_createdAt_idx" ON "StockoutAlert"("createdAt");

-- AddForeignKey
ALTER TABLE "StockoutPrediction" ADD CONSTRAINT "StockoutPrediction_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StockoutAlert" ADD CONSTRAINT "StockoutAlert_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE CASCADE ON UPDATE CASCADE;
