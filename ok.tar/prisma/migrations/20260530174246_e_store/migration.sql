/*
  Warnings:

  - You are about to drop the `StockoutAlert` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `StockoutPrediction` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "StockoutAlert" DROP CONSTRAINT "StockoutAlert_productId_fkey";

-- DropForeignKey
ALTER TABLE "StockoutPrediction" DROP CONSTRAINT "StockoutPrediction_productId_fkey";

-- DropTable
DROP TABLE "StockoutAlert";

-- DropTable
DROP TABLE "StockoutPrediction";

-- DropEnum
DROP TYPE "StockoutAlertStatus";
