import { Injectable, UnauthorizedException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { PassportStrategy } from "@nestjs/passport";
import { ExtractJwt, Strategy } from "passport-jwt";
import { ActiveUserSchema } from "../dto/request-user.dto";
import { EnvVariables } from "@/common/schema/env";
import { I18nService } from "nestjs-i18n";
import type { I18nTranslations } from "@/i18n/generated/i18n.generated";

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(
    configService: ConfigService<EnvVariables>,
    private readonly i18n: I18nService<I18nTranslations>,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      secretOrKey: configService.getOrThrow("JWT_SECRET", { infer: true }),
      audience: configService.get("JWT_AUDIENCE", { infer: true }),
      issuer: configService.get("JWT_ISSUER", { infer: true }),
      algorithms: ["HS256"],
      ignoreExpiration: false,
    });
  }

  override validate(payload: unknown) {
    const { data, success } = ActiveUserSchema.safeParse(payload);
    if (!success) {
      throw new UnauthorizedException(this.i18n.t("errors.auth.invalidToken"));
    }
    return data;
  }
}
