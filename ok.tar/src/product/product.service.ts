import { Injectable, BadRequestException, ConflictException } from "@nestjs/common";
import { I18nService } from "nestjs-i18n";
import type { I18nTranslations } from "@/i18n/generated/i18n.generated";

import { PrismaService } from "@/prisma/prisma.service";
import { CreateProductDto } from "./dto/create-product.dto";
import { UpdateProductDto } from "./dto/update-product.dto";
import { Prisma } from "@/prisma/client";
import { PaginationQueryDto } from "@/common/dto/pagination-query.dto";
import { paginated } from "@/common/types/paginated-response";

@Injectable()
export class ProductService {
  constructor(
    private readonly prismaService: PrismaService,
    private readonly i18n: I18nService<I18nTranslations>,
  ) {}

  public get prisma() {
    return this.prismaService.client;
  }

  async create(createProductDto: CreateProductDto) {
    const [_category, _supplier, existingProduct] = await Promise.all([
      this.prisma.category.findUniqueOrThrow({
        select: { id: true },
        where: { id: createProductDto.categoryId },
      }),
      this.prisma.supplier.findUniqueOrThrow({
        select: { id: true },
        where: { id: createProductDto.supplierId },
      }),
      this.prisma.product.findFirst({
        select: { id: true },
        where: { barcode: createProductDto.barcode },
      }),
    ]);

    // Check for duplicate barcode
    if (existingProduct) {
      throw new ConflictException(
        this.i18n.t("errors.product.barcodeExists", {
          args: { barcode: createProductDto.barcode },
        }),
      );
    }

    const product = await this.prisma.product.create({
      data: createProductDto,
      include: {
        category: true,
        supplier: true,
      },
    });
    return product;
  }

  async getProducts(query: PaginationQueryDto, search: string | undefined) {
    const where: Prisma.ProductWhereInput = search
      ? {
          OR: [
            { name: { contains: search, mode: "insensitive" } },
            { nameAr: { contains: search, mode: "insensitive" } },
            { barcode: { contains: search, mode: "insensitive" } },
          ],
        }
      : {};

    const [data, total] = await Promise.all([
      this.prisma.product.findMany({
        where,
        include: {
          category: true,
          supplier: true,
        },
        skip: query.offset,
        take: query.limit,
        orderBy: { createdAt: "desc" },
      }),
      this.prisma.product.count({ where }),
    ]);

    return paginated(data, total, query.limit, query.offset);
  }

  async findOne(id: number) {
    const product = await this.prisma.product.findUniqueOrThrow({
      where: { id },
      include: {
        category: true,
        supplier: true,
        productPhotos: {
          select: {
            id: true,
            storedFileId: true,
            createdAt: true,
            storedFile: { select: { id: true, originalname: true, mimetype: true } },
          },
          orderBy: { createdAt: "asc" },
        },
        saleItems: {
          select: {
            id: true,
            quantity: true,
            unitPrice: true,
            discount: true,
            invoice: {
              select: {
                id: true,
                createdAt: true,
              },
            },
          },
          take: 10,
          orderBy: { invoice: { createdAt: "desc" } },
        },
        orderItems: {
          select: {
            id: true,
            quantity: true,
          },
          take: 10,
        },
      },
    });

    return product;
  }

  async update(id: number, updateProductDto: UpdateProductDto) {
    // Verify product exists
    const product = await this.prisma.product.findUniqueOrThrow({
      where: { id },
    });

    // If barcode is being updated, check for duplicates
    if (updateProductDto.barcode && updateProductDto.barcode !== product.barcode) {
      const existingProduct = await this.prisma.product.findUnique({
        where: { barcode: updateProductDto.barcode },
      });
      if (existingProduct) {
        throw new ConflictException(
          this.i18n.t("errors.product.barcodeExists", {
            args: { barcode: updateProductDto.barcode },
          }),
        );
      }
    }

    // Verify category exists if being updated
    if (updateProductDto.categoryId && updateProductDto.categoryId !== product.categoryId) {
      await this.prisma.category.findUniqueOrThrow({
        select: { id: true },
        where: { id: updateProductDto.categoryId },
      });
    }

    // Verify supplier exists if being updated
    if (updateProductDto.supplierId && updateProductDto.supplierId !== product.supplierId) {
      await this.prisma.supplier.findUniqueOrThrow({
        select: { id: true },
        where: { id: updateProductDto.supplierId },
      });
    }

    const updatedProduct = await this.prisma.product.update({
      where: { id },
      data: updateProductDto,
      include: {
        category: true,
        supplier: true,
      },
    });

    return updatedProduct;
  }

  async remove(id: number) {
    await this.prisma.product.findUniqueOrThrow({
      where: { id },
    });

    // Check if product has been sold or is in orders
    const saleItems = await this.prisma.saleItem.count({
      where: { productId: id },
    });

    const orderItems = await this.prisma.orderItem.count({
      where: { productId: id },
    });

    if (saleItems > 0 || orderItems > 0) {
      throw new BadRequestException(this.i18n.t("errors.product.cannotDeleteWithOrders"));
    }

    await this.prisma.product.delete({
      where: { id },
    });

    return { message: this.i18n.t("responses.product.deleted", { args: { id } }) };
  }

  async getProductsByCategory(categoryId: number, query: PaginationQueryDto) {
    const _category = await this.prisma.category.findUniqueOrThrow({
      where: { id: categoryId },
    });

    const where = { categoryId };

    const [data, total] = await Promise.all([
      this.prisma.product.findMany({
        where,
        include: {
          category: true,
          supplier: true,
        },
        skip: query.offset,
        take: query.limit,
        orderBy: { createdAt: "desc" },
      }),
      this.prisma.product.count({ where }),
    ]);

    return paginated(data, total, query.limit, query.offset);
  }

  async getProductsBySupplier(supplierId: number, query: PaginationQueryDto) {
    const _supplier = await this.prisma.supplier.findUniqueOrThrow({
      where: { id: supplierId },
    });

    const where = { supplierId };

    const [data, total] = await Promise.all([
      this.prisma.product.findMany({
        where,
        include: {
          category: true,
          supplier: true,
        },
        skip: query.offset,
        take: query.limit,
        orderBy: { createdAt: "desc" },
      }),
      this.prisma.product.count({ where }),
    ]);

    return paginated(data, total, query.limit, query.offset);
  }

  async getLowStockProducts(query: PaginationQueryDto) {
    const where = {
      quantityInStock: {
        lte: this.prisma.product.fields.minQuantity,
      },
    };

    const [data, total] = await Promise.all([
      this.prisma.product.findMany({
        where,
        include: {
          category: true,
          supplier: true,
        },
        skip: query.offset,
        take: query.limit,
        orderBy: { quantityInStock: "asc" },
      }),
      this.prisma.product.count({ where }),
    ]);

    return paginated(data, total, query.limit, query.offset);
  }

  async updateStock(id: number, quantityInStock: number) {
    const _product = await this.prisma.product.findUniqueOrThrow({
      where: { id },
    });

    return this.prisma.product.update({
      where: { id },
      data: {
        quantityInStock: quantityInStock,
      },
      include: {
        category: true,
        supplier: true,
      },
    });
  }
}
