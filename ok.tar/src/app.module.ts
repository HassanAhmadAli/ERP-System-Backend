import { ZodValidationPipe, ZodSerializerInterceptor } from "nestjs-zod";
import { APP_PIPE, APP_INTERCEPTOR, APP_FILTER, APP_GUARD } from "@nestjs/core";
import { MiddlewareConsumer, Module, NestModule } from "@nestjs/common";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { EnvVariables, validateEnv } from "@/common/schema/env";
import { PrismaModule } from "@/prisma/prisma.module";
import { TimeoutInterceptor } from "@/common/interceptors/timeout.interceptor";
import { CacheModule } from "@nestjs/cache-manager";
import { UserModule } from "./user/user.module";
import { NotificationsModule } from "./notification/notification.module";
import KeyvRedis from "@keyv/redis";
import morgan from "morgan";
import { env } from "@/common/env";
import { ProductPhotoModule } from "./product-photo/product-photo.module";
import { ScheduleModule } from "@nestjs/schedule";
import { BullModule } from "@nestjs/bullmq";
import { BackupModule } from "./backup/backup.module";
import { GlobalExceptionFilter } from "./global-exception-filter";
import { PermissionsGuard } from "./access-control/guards/permissions.guard";
import { AuthenticationGuard } from "./authentication/guard/authentication.guard";
import { AuthenticationModule } from "./authentication/authentication.module";
import { CachingModule } from "./caching/caching.module";
import { UploadModule } from "./upload/upload.module";
import { ProductModule } from "./product/product.module";
import { CategoryModule } from "./category/category.module";
import { SupplierModule } from "./supplier/supplier.module";
import { CustomerModule } from "./customer/customer.module";
import { DiscountModule } from "./discount/discount.module";
import { SalesModule } from "./sales/sales.module";
import { OrderModule } from "./order/order.module";
import { PurchaseModule } from "./purchase/purchase.module";
import { ExpenseModule } from "./expense/expense.module";
import { ReportModule } from "./report/report.module";
import { HealthController } from "./health/health.controller";
import { LoyaltyRewardModule } from "./loyalty-offers/loyalty-discount-offer.module";
import { AuditLogModule } from "./audit-log/audit-log.module";
import { AdModule } from "./ad/ad.module";
import { FinancialModule } from "./financial/financial.module";
import { AuditContextInterceptor } from "./audit-log/audit-context.interceptor";
import { AcceptLanguageResolver, I18nModule, QueryResolver } from "nestjs-i18n";
import path from "node:path";
import { UserLanguageResolver } from "./i18n/resolvers/user-language.resolver";
import { ThrottlerModule } from "@nestjs/throttler";

@Module({
  imports: [
    ThrottlerModule.forRoot({
      throttlers: [{ name: "default", ttl: 60000, limit: 10 }],
    }),
    //// core imports
    BullModule.forRoot({
      connection: {
        url: env!.REDIS_DATABASE_URL,
      },
    }),
    ScheduleModule.forRoot(),
    CacheModule.registerAsync({
      isGlobal: true,
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService<EnvVariables>) => ({
        ttl: 5 * 60 * 1000,
        stores: [
          new KeyvRedis(
            configService.getOrThrow("REDIS_DATABASE_URL", {
              infer: true,
            }),
            {},
          ),
        ],
      }),
    }),
    ConfigModule.forRoot({
      isGlobal: true,
      load: [
        () => {
          return validateEnv(process.env);
        },
      ],
      validate: validateEnv,
    }),
    I18nModule.forRoot({
      fallbackLanguage: "en",
      fallbacks: { "en-*": "en", "ar-*": "ar" },
      loaderOptions: {
        path: path.join(__dirname, "./i18n"),
        watch: true,
      },
      resolvers: [new UserLanguageResolver(), { use: QueryResolver, options: ["lang"] }, AcceptLanguageResolver],
      typesOutputPath: path.join(__dirname, "../src/i18n/generated/i18n.generated.ts"),
    }),
    ////
    PrismaModule,
    UserModule,
    NotificationsModule,
    ProductPhotoModule,
    BackupModule,
    AuthenticationModule,
    CachingModule,
    UploadModule,
    ProductModule,
    CategoryModule,
    SupplierModule,
    CustomerModule,
    DiscountModule,
    SalesModule,
    OrderModule,
    PurchaseModule,
    ExpenseModule,
    ReportModule,
    LoyaltyRewardModule,
    AuditLogModule,
    AdModule,
    FinancialModule,
  ],
  controllers: [HealthController],
  providers: [
    {
      provide: APP_GUARD,
      useClass: AuthenticationGuard,
    },
    {
      provide: APP_GUARD,
      useClass: PermissionsGuard,
    },
    {
      provide: APP_FILTER,
      useClass: GlobalExceptionFilter,
    },
    {
      provide: APP_PIPE,
      useClass: ZodValidationPipe,
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: ZodSerializerInterceptor,
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: TimeoutInterceptor,
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: AuditContextInterceptor,
    },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    if (env?.NODE_ENV === "development") {
      consumer.apply(morgan("dev")).forRoutes("*");
    }
  }
}
